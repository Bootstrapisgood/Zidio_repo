import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface AnalysisHistory {
  id: string;
  fileName: string;
  uploadDate: string;
  chartType: string;
  xAxis: string;
  yAxis: string;
  chartData: any;
}

interface ExcelData {
  headers: string[];
  rows: any[][];
  fileName: string;
}

interface DataState {
  currentData: ExcelData | null;
  selectedXAxis: string;
  selectedYAxis: string;
  chartType: 'bar' | 'line' | 'pie' | 'scatter' | '3d-column';
  analysisHistory: AnalysisHistory[];
  isProcessing: boolean;
}

const initialState: DataState = {
  currentData: null,
  selectedXAxis: '',
  selectedYAxis: '',
  chartType: 'bar',
  analysisHistory: [],
  isProcessing: false,
};

const dataSlice = createSlice({
  name: 'data',
  initialState,
  reducers: {
    setCurrentData: (state, action: PayloadAction<ExcelData>) => {
      state.currentData = action.payload;
    },
    setSelectedAxes: (state, action: PayloadAction<{ xAxis: string; yAxis: string }>) => {
      state.selectedXAxis = action.payload.xAxis;
      state.selectedYAxis = action.payload.yAxis;
    },
    setChartType: (state, action: PayloadAction<DataState['chartType']>) => {
      state.chartType = action.payload;
    },
    addToHistory: (state, action: PayloadAction<AnalysisHistory>) => {
      state.analysisHistory.unshift(action.payload);
    },
    setProcessing: (state, action: PayloadAction<boolean>) => {
      state.isProcessing = action.payload;
    },
    clearCurrentData: (state) => {
      state.currentData = null;
      state.selectedXAxis = '';
      state.selectedYAxis = '';
    },
  },
});

export const {
  setCurrentData,
  setSelectedAxes,
  setChartType,
  addToHistory,
  setProcessing,
  clearCurrentData,
} = dataSlice.actions;

export default dataSlice.reducer;