import { ReactNode } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Maximize2, Settings } from "lucide-react";

interface ChartContainerProps {
  title: string;
  children: ReactNode;
  onDownload?: () => void;
  onFullscreen?: () => void;
  onSettings?: () => void;
  className?: string;
}

export function ChartContainer({ 
  title, 
  children, 
  onDownload, 
  onFullscreen, 
  onSettings,
  className = ""
}: ChartContainerProps) {
  return (
    <Card className={`gradient-card shadow-medium ${className}`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-lg font-semibold">{title}</CardTitle>
        <div className="flex items-center gap-2">
          {onSettings && (
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onSettings}
              className="hover:bg-accent"
            >
              <Settings className="w-4 h-4" />
            </Button>
          )}
          {onFullscreen && (
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onFullscreen}
              className="hover:bg-accent"
            >
              <Maximize2 className="w-4 h-4" />
            </Button>
          )}
          {onDownload && (
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onDownload}
              className="hover:bg-accent"
            >
              <Download className="w-4 h-4" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="w-full h-80 flex items-center justify-center">
          {children}
        </div>
      </CardContent>
    </Card>
  );
}