import { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Text } from "@react-three/drei";
import { ChartContainer } from "./ChartContainer";
import { useAppSelector } from "@/store/hooks";
import * as THREE from "three";

interface BarProps {
  position: [number, number, number];
  height: number;
  color: string;
  label: string;
}

function Bar({ position, height, color, label }: BarProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
    }
  });

  return (
    <group position={position}>
      <mesh ref={meshRef} position={[0, height / 2, 0]}>
        <boxGeometry args={[0.8, height, 0.8]} />
        <meshStandardMaterial color={color} />
      </mesh>
      <Text
        position={[0, -0.5, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        fontSize={0.3}
        color="#666"
        anchorX="center"
        anchorY="middle"
      >
        {label}
      </Text>
    </group>
  );
}

function Scene() {
  const { currentData, selectedXAxis, selectedYAxis } = useAppSelector(
    (state) => state.data
  );

  const chartData = useMemo(() => {
    if (!currentData || !selectedXAxis || !selectedYAxis) {
      return [];
    }

    const xIndex = currentData.headers.indexOf(selectedXAxis);
    const yIndex = currentData.headers.indexOf(selectedYAxis);

    if (xIndex === -1 || yIndex === -1) {
      return [];
    }

    const maxItems = 10; // Limit for performance
    const data = currentData.rows.slice(0, maxItems).map((row, index) => {
      const value = parseFloat(row[yIndex]) || 0;
      const label = String(row[xIndex]).substring(0, 8); // Truncate long labels
      
      return {
        x: (index - maxItems / 2) * 2,
        y: 0,
        z: 0,
        height: Math.max(value / 100, 0.1), // Scale and ensure minimum height
        color: `hsl(${(index * 360) / maxItems}, 70%, 60%)`,
        label,
      };
    });

    return data;
  }, [currentData, selectedXAxis, selectedYAxis]);

  if (chartData.length === 0) {
    return (
      <Text
        position={[0, 0, 0]}
        fontSize={0.5}
        color="#666"
        anchorX="center"
        anchorY="middle"
      >
        No data to display
      </Text>
    );
  }

  return (
    <>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      <spotLight
        position={[0, 15, 0]}
        angle={0.3}
        penumbra={1}
        intensity={1}
        castShadow
      />
      
      {chartData.map((item, index) => (
        <Bar
          key={index}
          position={[item.x, item.y, item.z]}
          height={item.height}
          color={item.color}
          label={item.label}
        />
      ))}
      
      <OrbitControls 
        enablePan={true} 
        enableZoom={true} 
        enableRotate={true}
        minDistance={5}
        maxDistance={20}
      />
      
      {/* Grid */}
      <gridHelper args={[20, 20, "#444", "#444"]} position={[0, -1, 0]} />
    </>
  );
}

interface Chart3DProps {
  className?: string;
}

export function Chart3D({ className }: Chart3DProps) {
  const { selectedXAxis, selectedYAxis } = useAppSelector(
    (state) => state.data
  );

  return (
    <ChartContainer 
      title={`3D Column Chart: ${selectedYAxis || 'Y-Axis'} vs ${selectedXAxis || 'X-Axis'}`}
      className={className}
      onDownload={() => {
        // TODO: Implement 3D chart download functionality
        console.log('Download 3D chart');
      }}
    >
      <div className="w-full h-full">
        <Canvas
          camera={{ position: [5, 5, 5], fov: 75 }}
          shadows
          className="bg-gradient-to-br from-background to-accent/20"
        >
          <Scene />
        </Canvas>
      </div>
    </ChartContainer>
  );
}