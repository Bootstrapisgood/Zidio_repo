import { useMemo } from "react";
import { Bar, Line, Pie, Scatter } from "react-chartjs-2";
import { ChartContainer } from "./ChartContainer";
import { useAppSelector } from "@/store/hooks";

interface Chart2DProps {
  className?: string;
}

export function Chart2D({ className }: Chart2DProps) {
  const { currentData, selectedXAxis, selectedYAxis, chartType } = useAppSelector(
    (state) => state.data
  );

  const chartData = useMemo(() => {
    if (!currentData || !selectedXAxis || !selectedYAxis) {
      return null;
    }

    const xIndex = currentData.headers.indexOf(selectedXAxis);
    const yIndex = currentData.headers.indexOf(selectedYAxis);

    if (xIndex === -1 || yIndex === -1) {
      return null;
    }

    const labels = currentData.rows.map(row => row[xIndex]).slice(0, 20); // Limit to 20 items
    const data = currentData.rows.map(row => parseFloat(row[yIndex]) || 0).slice(0, 20);

    const colors = [
      'hsl(230, 85%, 60%)',
      'hsl(235, 90%, 68%)',
      'hsl(142, 71%, 45%)',
      'hsl(38, 92%, 50%)',
      'hsl(0, 84%, 60%)',
      'hsl(270, 50%, 60%)',
      'hsl(180, 60%, 50%)',
      'hsl(320, 70%, 55%)',
    ];

    return {
      labels,
      datasets: [
        {
          label: selectedYAxis,
          data,
          backgroundColor: chartType === 'pie' 
            ? colors.slice(0, data.length)
            : 'hsla(230, 85%, 60%, 0.8)',
          borderColor: 'hsl(230, 85%, 60%)',
          borderWidth: 2,
          tension: 0.4,
        },
      ],
    };
  }, [currentData, selectedXAxis, selectedYAxis, chartType]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          usePointStyle: true,
          padding: 20,
        },
      },
      tooltip: {
        backgroundColor: 'hsl(224, 71%, 4%)',
        titleColor: 'hsl(220, 14%, 96%)',
        bodyColor: 'hsl(220, 14%, 96%)',
        borderColor: 'hsl(230, 85%, 60%)',
        borderWidth: 1,
      },
    },
    scales: chartType !== 'pie' ? {
      x: {
        grid: {
          color: 'hsl(220, 13%, 91%)',
        },
        ticks: {
          color: 'hsl(220, 8.9%, 46.1%)',
        },
      },
      y: {
        grid: {
          color: 'hsl(220, 13%, 91%)',
        },
        ticks: {
          color: 'hsl(220, 8.9%, 46.1%)',
        },
      },
    } : {},
  };

  if (!chartData) {
    return (
      <ChartContainer title={`${chartType} Chart`} className={className}>
        <div className="text-center text-muted-foreground">
          <p className="text-lg mb-2">No data to display</p>
          <p className="text-sm">Please upload data and select X and Y axes</p>
        </div>
      </ChartContainer>
    );
  }

  const renderChart = () => {
    switch (chartType) {
      case 'bar':
        return <Bar data={chartData} options={options} />;
      case 'line':
        return <Line data={chartData} options={options} />;
      case 'pie':
        return <Pie data={chartData} options={options} />;
      case 'scatter':
        return <Scatter data={chartData} options={options} />;
      default:
        return <Bar data={chartData} options={options} />;
    }
  };

  return (
    <ChartContainer 
      title={`${chartType.charAt(0).toUpperCase() + chartType.slice(1)} Chart: ${selectedYAxis} vs ${selectedXAxis}`}
      className={className}
      onDownload={() => {
        // TODO: Implement chart download functionality
        console.log('Download chart');
      }}
    >
      {renderChart()}
    </ChartContainer>
  );
}