import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { Upload, FileSpreadsheet, X, CheckCircle, AlertCircle } from "lucide-react";
import * as XLSX from "xlsx";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useAppDispatch } from "@/store/hooks";
import { setCurrentData, setProcessing } from "@/store/slices/dataSlice";
import { addNotification } from "@/store/slices/uiSlice";

export function FileUpload() {
  const dispatch = useAppDispatch();
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [fileName, setFileName] = useState('');

  const processFile = useCallback(async (file: File) => {
    setUploadStatus('uploading');
    setFileName(file.name);
    dispatch(setProcessing(true));

    try {
      const reader = new FileReader();
      
      reader.onprogress = (e) => {
        if (e.lengthComputable) {
          setUploadProgress((e.loaded / e.total) * 100);
        }
      };

      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          
          // Get the first worksheet
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          
          // Convert to JSON
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
            header: 1,
            defval: ''
          }) as any[][];

          if (jsonData.length === 0) {
            throw new Error('The Excel file appears to be empty');
          }

          const headers = jsonData[0] as string[];
          const rows = jsonData.slice(1);

          dispatch(setCurrentData({
            headers,
            rows,
            fileName: file.name
          }));

          setUploadStatus('success');
          dispatch(addNotification({
            type: 'success',
            message: `Successfully uploaded ${file.name} with ${rows.length} rows of data`
          }));

        } catch (error) {
          console.error('Error processing file:', error);
          setUploadStatus('error');
          dispatch(addNotification({
            type: 'error',
            message: 'Failed to process the Excel file. Please check the file format.'
          }));
        } finally {
          dispatch(setProcessing(false));
        }
      };

      reader.readAsArrayBuffer(file);
    } catch (error) {
      setUploadStatus('error');
      dispatch(setProcessing(false));
      dispatch(addNotification({
        type: 'error',
        message: 'Failed to read the file. Please try again.'
      }));
    }
  }, [dispatch]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      processFile(file);
    }
  }, [processFile]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls']
    },
    multiple: false,
    maxSize: 10 * 1024 * 1024 // 10MB
  });

  const resetUpload = () => {
    setUploadStatus('idle');
    setUploadProgress(0);
    setFileName('');
  };

  return (
    <Card className="gradient-card shadow-medium">
      <CardContent className="p-8">
        <div {...getRootProps()} className={`
          border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-300
          ${isDragActive 
            ? 'border-primary bg-primary/5 scale-[1.02]' 
            : 'border-border hover:border-primary/50 hover:bg-accent/50'
          }
        `}>
          <input {...getInputProps()} />
          
          {uploadStatus === 'idle' && (
            <div className="space-y-4">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                <Upload className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Upload Excel File
                </h3>
                <p className="text-muted-foreground mb-4">
                  {isDragActive 
                    ? "Drop the Excel file here..." 
                    : "Drag & drop an Excel file here, or click to select"
                  }
                </p>
                <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Supports .xlsx and .xls files (max 10MB)</span>
                </div>
              </div>
            </div>
          )}

          {uploadStatus === 'uploading' && (
            <div className="space-y-4">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center animate-pulse">
                <Upload className="w-8 h-8 text-primary animate-bounce" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Processing {fileName}...
                </h3>
                <Progress value={uploadProgress} className="mb-2" />
                <p className="text-sm text-muted-foreground">
                  {uploadProgress.toFixed(0)}% complete
                </p>
              </div>
            </div>
          )}

          {uploadStatus === 'success' && (
            <div className="space-y-4">
              <div className="w-16 h-16 mx-auto bg-success/10 rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-success" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Upload Successful!
                </h3>
                <p className="text-muted-foreground mb-4">
                  {fileName} has been processed successfully
                </p>
                <Button onClick={resetUpload} variant="outline">
                  Upload Another File
                </Button>
              </div>
            </div>
          )}

          {uploadStatus === 'error' && (
            <div className="space-y-4">
              <div className="w-16 h-16 mx-auto bg-destructive/10 rounded-full flex items-center justify-center">
                <AlertCircle className="w-8 h-8 text-destructive" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-destructive mb-2">
                  Upload Failed
                </h3>
                <p className="text-muted-foreground mb-4">
                  There was an error processing {fileName}
                </p>
                <Button onClick={resetUpload} variant="outline">
                  Try Again
                </Button>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}