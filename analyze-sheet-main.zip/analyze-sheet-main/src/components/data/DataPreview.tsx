import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAppSelector } from "@/store/hooks";

export function DataPreview() {
  const { currentData } = useAppSelector((state) => state.data);

  if (!currentData) {
    return (
      <div className="text-center text-muted-foreground py-8">
        No data to preview
      </div>
    );
  }

  const maxRows = 10; // Limit preview rows
  const previewRows = currentData.rows.slice(0, maxRows);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Showing {previewRows.length} of {currentData.rows.length} rows
        </div>
        {currentData.rows.length > maxRows && (
          <div className="text-sm text-muted-foreground">
            + {currentData.rows.length - maxRows} more rows
          </div>
        )}
      </div>
      
      <ScrollArea className="h-80 w-full rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {currentData.headers.map((header, index) => (
                <TableHead key={index} className="font-semibold">
                  {header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {previewRows.map((row, rowIndex) => (
              <TableRow key={rowIndex}>
                {row.map((cell, cellIndex) => (
                  <TableCell key={cellIndex} className="font-mono text-sm">
                    {String(cell)}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </ScrollArea>
    </div>
  );
}