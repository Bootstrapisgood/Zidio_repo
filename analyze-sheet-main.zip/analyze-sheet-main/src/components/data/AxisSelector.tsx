import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { setSelectedAxes } from "@/store/slices/dataSlice";

export function AxisSelector() {
  const dispatch = useAppDispatch();
  const { currentData, selectedXAxis, selectedYAxis } = useAppSelector(
    (state) => state.data
  );

  if (!currentData) {
    return (
      <Card className="gradient-card shadow-soft">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Axis Selection</CardTitle>
          <CardDescription>Upload data to select axes</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  const handleXAxisChange = (value: string) => {
    dispatch(setSelectedAxes({ xAxis: value, yAxis: selectedYAxis }));
  };

  const handleYAxisChange = (value: string) => {
    dispatch(setSelectedAxes({ xAxis: selectedXAxis, yAxis: value }));
  };

  return (
    <Card className="gradient-card shadow-soft">
      <CardHeader>
        <CardTitle className="text-sm font-medium">Axis Selection</CardTitle>
        <CardDescription>Choose your X and Y axes</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="x-axis">X-Axis</Label>
          <Select value={selectedXAxis} onValueChange={handleXAxisChange}>
            <SelectTrigger id="x-axis">
              <SelectValue placeholder="Select X-Axis" />
            </SelectTrigger>
            <SelectContent>
              {currentData.headers.map((header) => (
                <SelectItem key={header} value={header}>
                  {header}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="y-axis">Y-Axis</Label>
          <Select value={selectedYAxis} onValueChange={handleYAxisChange}>
            <SelectTrigger id="y-axis">
              <SelectValue placeholder="Select Y-Axis" />
            </SelectTrigger>
            <SelectContent>
              {currentData.headers.map((header) => (
                <SelectItem key={header} value={header}>
                  {header}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedXAxis && selectedYAxis && (
          <div className="mt-4 p-3 bg-success/10 rounded-lg border border-success/20">
            <div className="text-sm font-medium text-success">Ready to visualize!</div>
            <div className="text-xs text-muted-foreground mt-1">
              {selectedYAxis} vs {selectedXAxis}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}