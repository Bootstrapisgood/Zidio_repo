import { BarChart3, LineChart, PieChart, ScatterChart, Box } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { setChartType } from "@/store/slices/dataSlice";

const chartTypes = [
  { type: 'bar' as const, label: 'Bar Chart', icon: BarChart3 },
  { type: 'line' as const, label: 'Line Chart', icon: LineChart },
  { type: 'pie' as const, label: 'Pie Chart', icon: PieChart },
  { type: 'scatter' as const, label: 'Scatter Plot', icon: ScatterChart },
  { type: '3d-column' as const, label: '3D Column', icon: Box },
];

export function ChartTypeSelector() {
  const dispatch = useAppDispatch();
  const { chartType } = useAppSelector((state) => state.data);

  const handleChartTypeChange = (type: typeof chartType) => {
    dispatch(setChartType(type));
  };

  return (
    <Card className="gradient-card shadow-soft">
      <CardHeader>
        <CardTitle className="text-sm font-medium">Chart Type</CardTitle>
        <CardDescription>Choose your visualization style</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-2">
          {chartTypes.map(({ type, label, icon: Icon }) => (
            <Button
              key={type}
              variant={chartType === type ? "default" : "outline"}
              size="sm"
              className={`h-auto p-3 flex flex-col gap-2 transition-all duration-200 ${
                chartType === type 
                  ? "gradient-primary text-primary-foreground shadow-glow" 
                  : "hover:bg-accent"
              }`}
              onClick={() => handleChartTypeChange(type)}
            >
              <Icon className="w-4 h-4" />
              <span className="text-xs font-medium">{label}</span>
            </Button>
          ))}
        </div>

        {chartType && (
          <div className="mt-4 p-3 bg-primary/10 rounded-lg border border-primary/20">
            <div className="text-sm font-medium text-primary">
              {chartTypes.find(ct => ct.type === chartType)?.label} Selected
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              Perfect for visualizing your data relationships
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}