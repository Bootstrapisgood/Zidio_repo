import { Chart2D } from "@/components/charts/Chart2D";
import { Chart3D } from "@/components/charts/Chart3D";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Download, RefreshCw, Settings } from "lucide-react";
import { useAppSelector } from "@/store/hooks";

export default function Analytics() {
  const { currentData, selectedXAxis, selectedYAxis } = useAppSelector(
    (state) => state.data
  );

  if (!currentData) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Analytics</h1>
          <p className="text-muted-foreground mt-1">
            Advanced data visualization and analysis
          </p>
        </div>
        
        <Card className="gradient-card shadow-medium">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center">
                <Settings className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold">No Data Available</h3>
              <p className="text-muted-foreground max-w-md">
                Upload an Excel file and configure your axes to start analyzing your data.
              </p>
              <Button asChild className="gradient-primary">
                <a href="/upload">Upload Data</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Analytics</h1>
          <p className="text-muted-foreground mt-1">
            Advanced visualizations for {currentData.fileName}
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export All
          </Button>
        </div>
      </div>

      {selectedXAxis && selectedYAxis ? (
        <Tabs defaultValue="2d" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="2d">2D Visualizations</TabsTrigger>
            <TabsTrigger value="3d">3D Visualizations</TabsTrigger>
          </TabsList>
          
          <TabsContent value="2d" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Chart2D />
              <Card className="gradient-card shadow-medium">
                <CardHeader>
                  <CardTitle>Data Summary</CardTitle>
                  <CardDescription>Key statistics from your dataset</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-primary/10 rounded-lg">
                      <div className="text-2xl font-bold text-primary">
                        {currentData.rows.length}
                      </div>
                      <div className="text-sm text-muted-foreground">Total Rows</div>
                    </div>
                    <div className="text-center p-4 bg-success/10 rounded-lg">
                      <div className="text-2xl font-bold text-success">
                        {currentData.headers.length}
                      </div>
                      <div className="text-sm text-muted-foreground">Columns</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Selected Analysis</h4>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <p><strong>X-Axis:</strong> {selectedXAxis}</p>
                      <p><strong>Y-Axis:</strong> {selectedYAxis}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="3d" className="space-y-6">
            <Chart3D />
          </TabsContent>
        </Tabs>
      ) : (
        <Card className="gradient-card shadow-medium">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 mx-auto bg-warning/10 rounded-full flex items-center justify-center">
                <Settings className="w-8 h-8 text-warning" />
              </div>
              <h3 className="text-lg font-semibold">Configure Analysis</h3>
              <p className="text-muted-foreground max-w-md">
                Select your X and Y axes to start generating visualizations.
              </p>
              <Button asChild variant="outline">
                <a href="/upload">Configure Axes</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}