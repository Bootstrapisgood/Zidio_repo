import { useState } from "react";
import { FileUpload } from "@/components/upload/FileUpload";
import { DataPreview } from "@/components/data/DataPreview";
import { AxisSelector } from "@/components/data/AxisSelector";
import { ChartTypeSelector } from "@/components/data/ChartTypeSelector";
import { Chart2D } from "@/components/charts/Chart2D";
import { Chart3D } from "@/components/charts/Chart3D";
import { useAppSelector } from "@/store/hooks";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Upload() {
  const { currentData, selectedXAxis, selectedYAxis, chartType } = useAppSelector(
    (state) => state.data
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Upload & Analyze</h1>
        <p className="text-muted-foreground mt-1">
          Upload your Excel files and create beautiful visualizations
        </p>
      </div>

      {/* File Upload */}
      <FileUpload />

      {/* Data Analysis Section */}
      {currentData && (
        <div className="space-y-6">
          {/* Data Preview */}
          <Card className="gradient-card shadow-medium">
            <CardHeader>
              <CardTitle>Data Preview</CardTitle>
              <CardDescription>
                Showing data from {currentData.fileName}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DataPreview />
            </CardContent>
          </Card>

          {/* Chart Configuration */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <AxisSelector />
            <ChartTypeSelector />
            <Card className="gradient-card shadow-soft">
              <CardHeader>
                <CardTitle className="text-sm font-medium">Chart Preview</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedXAxis && selectedYAxis ? (
                  <div className="text-sm text-muted-foreground">
                    <p><strong>X-Axis:</strong> {selectedXAxis}</p>
                    <p><strong>Y-Axis:</strong> {selectedYAxis}</p>
                    <p><strong>Type:</strong> {chartType}</p>
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">
                    Select X and Y axes to preview your chart
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          {selectedXAxis && selectedYAxis && (
            <div>
              <h2 className="text-xl font-semibold text-foreground mb-4">
                Visualizations
              </h2>
              <Tabs defaultValue="2d" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="2d">2D Charts</TabsTrigger>
                  <TabsTrigger value="3d">3D Charts</TabsTrigger>
                </TabsList>
                <TabsContent value="2d" className="space-y-4">
                  <Chart2D />
                </TabsContent>
                <TabsContent value="3d" className="space-y-4">
                  <Chart3D />
                </TabsContent>
              </Tabs>
            </div>
          )}
        </div>
      )}
    </div>
  );
}