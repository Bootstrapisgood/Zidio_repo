import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileSpreadsheet, Calendar, BarChart3, Download, Eye } from "lucide-react";
import { useAppSelector } from "@/store/hooks";

export default function History() {
  const { analysisHistory } = useAppSelector((state) => state.data);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Analysis History</h1>
          <p className="text-muted-foreground mt-1">
            View and manage your previous data analyses
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            Export History
          </Button>
        </div>
      </div>

      {analysisHistory.length === 0 ? (
        <Card className="gradient-card shadow-medium">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center">
                <FileSpreadsheet className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold">No Analysis History</h3>
              <p className="text-muted-foreground max-w-md">
                Start analyzing your Excel data to build up your history of visualizations and insights.
              </p>
              <Button className="gradient-primary" asChild>
                <a href="/upload">Start Analyzing</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {analysisHistory.map((analysis) => (
            <Card key={analysis.id} className="gradient-card shadow-soft hover:shadow-medium transition-all duration-300">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-primary" />
                    <CardTitle className="text-base truncate">
                      {analysis.fileName}
                    </CardTitle>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {analysis.chartType}
                  </Badge>
                </div>
                <CardDescription className="flex items-center gap-1 text-xs">
                  <Calendar className="w-3 h-3" />
                  {new Date(analysis.uploadDate).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="text-sm">
                    <span className="font-medium">X-Axis:</span> {analysis.xAxis}
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">Y-Axis:</span> {analysis.yAxis}
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Eye className="w-3 h-3 mr-1" />
                    View
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Download className="w-3 h-3 mr-1" />
                    Export
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="gradient-card shadow-soft">
          <CardContent className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Analyses</p>
              <p className="text-2xl font-bold">{analysisHistory.length}</p>
            </div>
            <BarChart3 className="w-8 h-8 text-primary" />
          </CardContent>
        </Card>
        
        <Card className="gradient-card shadow-soft">
          <CardContent className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Files Processed</p>
              <p className="text-2xl font-bold">
                {new Set(analysisHistory.map(a => a.fileName)).size}
              </p>
            </div>
            <FileSpreadsheet className="w-8 h-8 text-success" />
          </CardContent>
        </Card>
        
        <Card className="gradient-card shadow-soft">
          <CardContent className="flex items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-muted-foreground">This Month</p>
              <p className="text-2xl font-bold">
                {analysisHistory.filter(a => 
                  new Date(a.uploadDate).getMonth() === new Date().getMonth()
                ).length}
              </p>
            </div>
            <Calendar className="w-8 h-8 text-warning" />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}