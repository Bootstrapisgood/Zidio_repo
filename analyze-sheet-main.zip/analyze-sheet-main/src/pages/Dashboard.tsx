import { BarChart3, FileSpreadsheet, TrendingUp, Users } from "lucide-react";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { Chart2D } from "@/components/charts/Chart2D";
import { Chart3D } from "@/components/charts/Chart3D";
import { FileUpload } from "@/components/upload/FileUpload";
import { useAppSelector } from "@/store/hooks";

export default function Dashboard() {
  const { currentData } = useAppSelector((state) => state.data);
  const { user } = useAppSelector((state) => state.auth);

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-muted-foreground mt-1">
            Here's what's happening with your data analytics today.
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Files Processed"
          value="24"
          description="This month"
          icon={FileSpreadsheet}
          trend={{ value: 12, isPositive: true }}
        />
        <StatsCard
          title="Charts Generated"
          value="156"
          description="Total visualizations"
          icon={BarChart3}
          trend={{ value: 8, isPositive: true }}
        />
        <StatsCard
          title="Data Points Analyzed"
          value="2.1M"
          description="Across all files"
          icon={TrendingUp}
          trend={{ value: 23, isPositive: true }}
        />
        <StatsCard
          title="Active Users"
          value="12"
          description="In your organization"
          icon={Users}
          trend={{ value: 2, isPositive: false }}
        />
      </div>

      {/* File Upload Section */}
      {!currentData && (
        <div>
          <h2 className="text-xl font-semibold text-foreground mb-4">
            Start Your Analysis
          </h2>
          <FileUpload />
        </div>
      )}

      {/* Charts Section */}
      {currentData && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold text-foreground mb-4">
              Data Visualizations
            </h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Chart2D />
              <Chart3D />
            </div>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="gradient-card shadow-soft p-6 rounded-lg">
          <h3 className="font-semibold text-foreground mb-2">Recent Files</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Access your recently uploaded files
          </p>
          <div className="space-y-2">
            <div className="text-sm text-muted-foreground">No recent files</div>
          </div>
        </div>
        
        <div className="gradient-card shadow-soft p-6 rounded-lg">
          <h3 className="font-semibold text-foreground mb-2">AI Insights</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Smart analysis of your data
          </p>
          <div className="text-sm text-muted-foreground">
            Upload data to get AI-powered insights
          </div>
        </div>
        
        <div className="gradient-card shadow-soft p-6 rounded-lg">
          <h3 className="font-semibold text-foreground mb-2">Export Options</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Download your charts and reports
          </p>
          <div className="text-sm text-muted-foreground">
            Generate charts to enable exports
          </div>
        </div>
      </div>
    </div>
  );
}