import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileSpreadsheet, BarChart3, Upload, Settings, Mail, Book, Video } from "lucide-react";

export default function Help() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Help & Documentation</h1>
        <p className="text-muted-foreground mt-1">
          Everything you need to know about using ExcelAnalytics
        </p>
      </div>

      {/* Quick Start Guide */}
      <Card className="gradient-card shadow-medium">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Book className="w-5 h-5 text-primary" />
            Quick Start Guide
          </CardTitle>
          <CardDescription>
            Get up and running with ExcelAnalytics in minutes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-primary/10 rounded-lg">
              <Upload className="w-8 h-8 text-primary mx-auto mb-2" />
              <h3 className="font-semibold text-sm mb-1">1. Upload Data</h3>
              <p className="text-xs text-muted-foreground">
                Upload your Excel file (.xls or .xlsx)
              </p>
            </div>
            <div className="text-center p-4 bg-success/10 rounded-lg">
              <Settings className="w-8 h-8 text-success mx-auto mb-2" />
              <h3 className="font-semibold text-sm mb-1">2. Configure</h3>
              <p className="text-xs text-muted-foreground">
                Select your X and Y axes
              </p>
            </div>
            <div className="text-center p-4 bg-warning/10 rounded-lg">
              <BarChart3 className="w-8 h-8 text-warning mx-auto mb-2" />
              <h3 className="font-semibold text-sm mb-1">3. Visualize</h3>
              <p className="text-xs text-muted-foreground">
                Choose from 2D and 3D charts
              </p>
            </div>
            <div className="text-center p-4 bg-destructive/10 rounded-lg">
              <FileSpreadsheet className="w-8 h-8 text-destructive mx-auto mb-2" />
              <h3 className="font-semibold text-sm mb-1">4. Export</h3>
              <p className="text-xs text-muted-foreground">
                Download your visualizations
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* FAQ Section */}
      <Card className="gradient-card shadow-medium">
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
          <CardDescription>
            Common questions and answers about using the platform
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>What file formats are supported?</AccordionTrigger>
              <AccordionContent>
                ExcelAnalytics supports both .xls and .xlsx file formats. The maximum file size is 10MB. 
                Make sure your Excel file has headers in the first row for the best experience.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger>How do I create 3D visualizations?</AccordionTrigger>
              <AccordionContent>
                After uploading your data and selecting your axes, navigate to the Analytics page or 
                Upload page and switch to the 3D tab. The 3D column chart provides an interactive 
                way to explore your data with rotation and zoom controls.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3">
              <AccordionTrigger>Can I export my charts?</AccordionTrigger>
              <AccordionContent>
                Yes! Each chart has export options available through the download button. You can 
                export charts as PNG images or PDF files. The export functionality is currently 
                being enhanced with more format options.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4">
              <AccordionTrigger>Is my data secure?</AccordionTrigger>
              <AccordionContent>
                Your data security is our priority. All uploaded files are processed locally in your 
                browser when possible, and any data sent to servers is encrypted in transit. 
                We recommend connecting to Supabase for enhanced security features.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5">
              <AccordionTrigger>What chart types are available?</AccordionTrigger>
              <AccordionContent>
                ExcelAnalytics offers multiple visualization options including Bar Charts, Line Charts, 
                Pie Charts, Scatter Plots, and 3D Column Charts. Each chart type is optimized for 
                different data relationships and analysis needs.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Feature Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="gradient-card shadow-soft">
          <CardHeader>
            <CardTitle className="text-lg">Platform Features</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2">
              <Badge variant="secondary">Data Upload</Badge>
              <span className="text-sm">Excel file processing</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">2D Charts</Badge>
              <span className="text-sm">Bar, Line, Pie, Scatter</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">3D Charts</Badge>
              <span className="text-sm">Interactive 3D columns</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">Data Preview</Badge>
              <span className="text-sm">Table view of your data</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">History</Badge>
              <span className="text-sm">Track your analyses</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">Export</Badge>
              <span className="text-sm">Download visualizations</span>
            </div>
          </CardContent>
        </Card>

        <Card className="gradient-card shadow-soft">
          <CardHeader>
            <CardTitle className="text-lg">Need More Help?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Can't find what you're looking for? Get in touch with our support team.
            </p>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                <Mail className="w-4 h-4 mr-2" />
                Contact Support
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Video className="w-4 h-4 mr-2" />
                Video Tutorials
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Book className="w-4 h-4 mr-2" />
                User Manual
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}